import React from 'react';
import './infocss.css';

const InfoPage = () => {
  return (
    <div className="info-container">
  <img src="/jakdanglabs_logo4x.png" alt="로고" className="logo" />

  {/* 네비게이션 메뉴 */}
  <div className="nav-menu">
    <div className="nav-item">작당연구소 소개</div>
    <div className="nav-item">서비스</div>
    <div className="nav-item">안내</div>
  </div>

  {/* 구분선 */}
  <div className="divider-line" />

  {/* 제목 */}
  <h1 className="info-title">
    AI활용으로 함께 만드는 창작의 흐름<br />
    모두가 연결되는 커뮤니티, <span className="highlight-orange">작당연구소</span>
  </h1>

  <div className="yellow-section">
  <img src="hands.png" alt="손 사진" className="hands-image" />
  </div>

  <div className="description-text">
  작당연구소는 공동의 관심사를 가진 인재들이 AI 기술을 활용해 창작 역량을 확장하고,  
  커뮤니티와 함께 성장하며, 커리어를 쌓아나가는 창의인재중심 연구소입니다.
  </div>

  <div className="about-section">
  {/* 왼쪽 이미지 */}
  <div className="about-image">
    <img src="/teaching.png" alt="교육 이미지" />
  </div>

  {/* 오른쪽 텍스트 박스 */}
  <div className="about-text-wrapper">
    <div className="about-label">
      <span>About 작당연구소</span>
      <div className="about-dot" />
    </div>

    <h2 className="about-title">
      기술이 창작을 돕고,<br />
      사람이 사람을 이끌어주는 곳
    </h2>

    <p className="about-description">
      작당연구소는 AI와 사람의 협업을 통해 창작의 새로운 패러다임을 제시하는 허브 플랫폼입니다.
      생성형 AI 도구를 활용한 콘텐츠 제작부터 커뮤니티 기반의 협업 프로젝트, 온·오프라인 교육과 창작 멘토링,
      프로젝트 중심의 커리어 성장, 그리고 작업물의 유통 및 수익화까지, 창작의 전 과정을 아우르는 지원을 제공합니다.
      기술이 창작을 돕고, 사람이 사람을 이끌며 함께 나아가는 이 흐름이 바로 작당연구소의 핵심입니다.
    </p>
  </div>
</div>




     </div>
  );
};

export default InfoPage;